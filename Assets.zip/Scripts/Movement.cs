﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour
{
    public CharacterController controller;
    public float speed = 3f;
    Vector3 velocity;
    public float gravity = -9.81f;
    public Transform ground;
    public LayerMask groundMask;
    public float distance = 0.05f;
    bool isGrounded;
    public float jumpHeight = 3f;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        isGrounded = Physics.CheckSphere(ground.position, distance, groundMask);

        if(isGrounded && velocity.y < 0)
        {
            velocity.y = -2f;       // keeps you on the ground
        }

        float x = Input.GetAxis("Horizontal");
        float z = Input.GetAxis("Vertical");

        Vector3 move = transform.right * x + transform.forward * z;
        controller.Move(move*speed*Time.deltaTime);         //gives command to the fps controller to move the character

        if(Input.GetButtonDown("Jump") && isGrounded)
        {
            velocity.y = Mathf.Sqrt(jumpHeight * -1f * gravity);    // checks if the character is on the ground then allows them to jump, bug here allows jumping even off the ground
            isGrounded = false;
        }
        velocity.y += gravity * Time.deltaTime;     //gravity
        controller.Move(velocity * Time.deltaTime); //allows character to move
    }
}
