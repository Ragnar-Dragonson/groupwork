﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Interaction : MonoBehaviour
{
    Camera cam;
    RaycastHit hit;
    public static string selectedObject;
    public bool highlight = false;
    public bool unHighlight = false;
    GameObject tempObj;
    public bool key = false;
    public Color colour;
    public Color highL = Color.yellow;
    public Vector3 traget;
    public bool move = false;
    GameObject hitObj;
    public LayerMask lavaMask;
    public float distance = 0.4f;
    public Transform lava;
    int Lives = 3;
    string endGameCriteria;
    GameObject boxes;
    Vector3 originaposition;
    GameObject[] oGboxList;
    Text lIves;
    // Start is called before the first frame update
    void Start()
    {
        Cursor.visible = false;
        
        cam = Camera.main;
        originaposition = GameObject.Find("Character").transform.position;

        lIves = GameObject.Find("Lives").GetComponent<Text>();
        key = false;

        oGboxList = GameObject.FindGameObjectsWithTag("Box");
    }
    
    void KeyCheck(GameObject obJ)
    {
        if(obJ.name == "CorrectKey")
        {
            obJ.GetComponent<Renderer>().material.color = new Vector4(0, .73f, 1, 1);
        }
            else if (obJ.name == "Key1")       // these return the keys to the original colours
            {
                obJ.GetComponent<Renderer>().material.color = new Vector4(.76f, 0, 0, 1);
            }
            else if (obJ.name == "Key2")
            {
                obJ.GetComponent<Renderer>().material.color = new Vector4(0.02f, .65f, 0, 1);
            }
            else if (obJ.name == "Key3")
            {
                obJ.GetComponent<Renderer>().material.color = new Vector4(1, 0, .8f, 1);

            }
    }

    private void Unhighlight(GameObject oBject)
    {
        if (oBject != null)
        {
            if (oBject.tag.Contains("Key"))
            {
                KeyCheck(oBject);          
            }
    
            else if (oBject.tag == "Door")
            {
                colour = Color.grey;
                oBject.GetComponent<Renderer>().material.color = colour;
            }
            else if (oBject.tag == "Box")
            {
                oBject.GetComponent<Renderer>().material.color = new Vector4(.75f, .44f, .01f, .63f);
            }
            else if (oBject.tag == "Crystal")
            {
                oBject.GetComponent<Renderer>().material.color = new Vector4(1, 0, .15f, .25f);
            }
            else if (oBject.tag == "Btn")
            {
                oBject.GetComponent<Renderer>().material.color = new Vector4(.76f, 0, 0, 1);
            }

        }
        unHighlight = false;
    }

    //private void MoveDoor(GameObject obj)
    //{
    //    obj.transform.position = Vector3.MoveTowards(obj.transform.position, traget, Time.deltaTime * 0.5f);

    //    if (obj.transform.position == traget)   // when doors are clicked they are told to move to a target position to give sense of opening a door
    //    {
    //        move = false;
    //    }
    //}                 //this was meant to move the doors but adding more code broke this mechanic therefore the code was moved back to the update function

    private void Highlight(GameObject oB)
    {
   
        oB.GetComponent<Renderer>().material.color = highL;       
        unHighlight = true;         //changes the material colour to yellow to give an idea to the player that they can interact
        tempObj = oB;
    }

   
    // Update is called once per frame
    void Update()
    {
        if(move == true)
        {
            hitObj.transform.position = Vector3.MoveTowards(hitObj.transform.position, traget, Time.deltaTime * 0.5f);

            if (hitObj.transform.position == traget)   // when doors are clicked they are told to move to a target position to give sense of opening a door
            {
                move = false;
            }
            //MoveDoor(hitObj);
            //move = false;
        }
        if (Physics.CheckSphere(lava.position, distance, lavaMask) == true)
        {
            Lives--;
            if (Lives == 0)
            { // checks to see if the player has fallen in the lava pool in the lava room if they have then proceed with following code

                endGameCriteria = "Loss";
                EndGame(endGameCriteria);
            }
            else
            {
                lIves.text = ("Lives: " + Lives);
                GameObject.Find("Character").transform.position = originaposition;
            }
        }
       
        if (Physics.Raycast(transform.position, cam.transform.forward, out hit) == true)
        {
            if (hit.transform.gameObject.tag == "Crystal")
            {
                if (Vector3.Distance(cam.transform.position, hit.transform.position) < 2f)
                {
                    highlight = true;   // checks to see if the user is looking at the crystal
                }
            }
            if (hit.transform.gameObject.tag == "Highlightable" || hit.transform.gameObject.tag == "Door" || hit.transform.gameObject.tag == "Key" || hit.transform.gameObject.tag == "CorrectKey" || hit.transform.gameObject.tag == "Crystal" || hit.transform.gameObject.tag == "Box" || hit.transform.gameObject.tag == "Btn") {
                 // checks to see if user is looking at an interactable object then tells the program to highlight the relevant object
                if (Vector3.Distance(cam.transform.position, hit.transform.position) < 2f)
                {
                    highlight = true;
                }             
            }
            else
            {
                highlight = false;
            }

            if (highlight == true)
            {
      
                Highlight(hit.transform.gameObject);
            }
            else if (unHighlight == true)
            {
                Unhighlight(tempObj);
            }
        
        }


        #region Object Interaction
        if (Input.GetMouseButtonDown(0))
        {
            Ray ray = cam.ScreenPointToRay(Input.mousePosition);

            if (Physics.Raycast(ray, out hit))  // gets the object that is hit by the raycast
            {
                hitObj = hit.transform.gameObject;
                if (hitObj.transform != null)
                {

                    if (highlight == true)
                    {

                        if (hitObj.transform.gameObject.tag == "CorrectKey" && hitObj.GetComponent<Renderer>().material.color == highL)
                        {
                            key = true;
                            Destroy(hitObj);    // uses destroy object to simulate picking up keys and crystal when clicked on
                        }
                        else if (hitObj.gameObject.tag == "Key" && hitObj.GetComponent<Renderer>().material.color == highL)
                        {               
                            Lives--;

                            if (Lives == 0)
                            { // checks to see if the player has fallen in the lava pool in the lava room if they have then proceed with following code

                                endGameCriteria = "Loss";
                                EndGame(endGameCriteria);
                            }
                            else
                            {
                                Destroy(hitObj);
                                lIves.text = ("Lives: " + Lives);
                                GameObject.Find("Character").transform.position = originaposition;
                            }
                        }
                        else if (hitObj.gameObject.tag == "Crystal" && hitObj.GetComponent<Renderer>().material.color == highL)
                        {
                            Destroy(hitObj);
                            endGameCriteria = "Win";
                            EndGame(endGameCriteria);

                        }

                        else if (hitObj.name == "Door1" && hitObj.GetComponent<Renderer>().material.color == highL)
                        {
                            if (key == true)
                            {
                                traget = hitObj.transform.position + new Vector3(0, 1.5f, 0);

                                move = true; // door1 has to be seperate due to the requirement of a key
                                //moveDoor(hitObj); // moves the doors  
                            }
                        }
                        else if (hitObj.tag == "Door" && hitObj.GetComponent<Renderer>().material.color == highL)
                        {
                            traget = hitObj.transform.position + new Vector3(0, 1.5f, 0);
                            move = true;
                           // moveDoor(hitObj); // moves the doors  

                        }
                        else if (hitObj.tag == "Btn" && hitObj.GetComponent<Renderer>().material.color == highL)
                        {
                            GameObject[] boxList = GameObject.FindGameObjectsWithTag("Box");
                            foreach (GameObject box in boxList)
                            {
                                foreach (GameObject boxes in oGboxList)
                                {
                                   
                                       box.transform.position = boxes.transform.position;
                                    box.transform.rotation = boxes.transform.rotation;
                                    
                                }
                                    
                          
                            //  box.SetActive(false);
                        //   box.SetActive(true);
                                //  box.GetComponent<Renderer>().enabled = true;
                            }

                        }

                    }

                }
            }
        } 
        #endregion

    }
    private void EndGame(string winOrLoss)
    {
        if(winOrLoss == "Win")
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 2);
            Cursor.visible = true;
            SceneManager.UnloadSceneAsync(SceneManager.GetActiveScene()); //goes back to main menu
            
        }
        else if (winOrLoss == "Loss")
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1); // goes to game over scene
            Cursor.visible = true;
            SceneManager.UnloadSceneAsync(SceneManager.GetActiveScene());
        }
        

    }
    

}

  
