﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
   
    
     void Start()
    {
        Cursor.lockState = CursorLockMode.None;
    }
    // Start is called before the first frame update
    public void LoadScene()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1); // switch to next scene
    }
    public void QuitGame()
    {
        Application.Quit(); // quit the game
    }
  
}
