﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Carry : MonoBehaviour
{

    public Transform local;
    Camera cam;

    // Start is called before the first frame update

    private void OnMouseDown()
    {
        {
            if (Vector3.Distance(cam.transform.position, this.transform.position) < 2.5f)
            {
                GetComponent<Rigidbody>().useGravity = false;

                //   GetComponent<BoxCollider>().enabled = false;
                this.transform.position  +=  new Vector3(0, 1f,.3f);    // moves whatever item they have picked up to above and infront
                this.transform.parent = GameObject.Find("Holding").transform;

            }
        }
    }
    private void OnMouseUp()
    {
        this.transform.parent = null;

        GetComponent<Rigidbody>().useGravity = true;    // as the item is let go of give back gravity to allow fall using the rigidbody gravity

        GetComponent<BoxCollider>().enabled = true;
    }
    void Start()
    {
        cam = Camera.main;
        
    }
    // Update is called once per frame

}
