﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Interaction : MonoBehaviour
{
    Camera cam;
    RaycastHit hit;
    public static string selectedObject;
    public bool highlight = false;
    public bool unHighlight = false;
    GameObject tempObj;
    public bool key = false;
    public Color colour;
    public Color highL = Color.yellow;
    public Vector3 traget;
    public bool move = false;
    GameObject oBject, hitObj;
    public LayerMask lavaMask;
    public float distance = 0.4f;
    public Transform lava;
    bool win, end, dead;

    Vector3 originaposition;
    Text gO,wI;
    // Start is called before the first frame update
    void Start()
    {
        cam = Camera.main;
        originaposition = GameObject.Find("Character").transform.position;
        gO = GameObject.FindGameObjectWithTag("GameOver").GetComponent<Text>(); // gets the text component for game over
        wI = GameObject.FindGameObjectWithTag("Win").GetComponent<Text>();// gets the text component for win
        key = false;
        end = false;
        dead = false;
    }


    private void Unhighlight(GameObject oBject)
    {
        if (oBject != null)
        {
            if (oBject.tag == "CorrectKey")
            {
                
                oBject.GetComponent<Renderer>().material.color = new Vector4(255, 255, 0, 255); ;
            }
            if (oBject.tag == "Key")
            {
                if(oBject.name == "Key1")       // these are meant to return the colours back to originals but does not fully work
                {
                    oBject.GetComponent<Renderer>().material.color = new Vector4(255,0,208, 255);
                }
                else if (oBject.name == "Key2")
                {
                    oBject.GetComponent<Renderer>().material.color = new Vector4(4, 166, 0, 255);
                }
                else if (oBject.name == "Key3")
                {
                    oBject.GetComponent<Renderer>().material.color = new Vector4(195, 0, 0, 255);
                }
           
            }
            
            else if (oBject.tag == "Door")
            {
                colour = Color.grey;
                oBject.GetComponent<Renderer>().material.color = colour;
            }
            
        }
        unHighlight = false;
    }

    private void moveDoor(GameObject obj)
    {
        obj.transform.position = Vector3.MoveTowards(obj.transform.position, traget, Time.deltaTime * 0.5f);

        if (obj.transform.position == traget)   // when doors are clicked they are told to move to a target position to give sense of opening a door
        {
            move = false;
        }
    }

    private void Highlight(GameObject oB)
    {
   
        oB.GetComponent<Renderer>().material.color = highL;       
        unHighlight = true;         //changes the material colour to yellow to give an idea to the player that they can interact
        tempObj = oB;
    }

   
    // Update is called once per frame
    void Update()
    {
        if (end == true && Input.GetButtonDown("Jump"))
        { // closes the application when the win statement is complete and player presses space bar
            Application.Quit();
            //SceneManager.LoadScene("GameScene"); couldnt get this to reload the scene
        }

        dead = Physics.CheckSphere(lava.position, distance, lavaMask);
        if (dead == true)
        { // checks to see if the player has fallen in the lava pool in the lava room if they have then proceed with following code
            gO.text = "GAME OVER PRESS SPACE TO CLOSE THE GAME";
            end = true;
            GameObject.Find("Character").transform.position = originaposition;
            
        }
        //transform.TransformDirection(Vector3.forward)
        if (Physics.Raycast(transform.position, cam.transform.forward, out hit) == true)
        {
            if (hit.transform.gameObject.tag == "Crystal")
            {
                if (Vector3.Distance(cam.transform.position, hit.transform.position) < 5f)
                {
                    highlight = true;   // checks to see if the user is looking at the crystal
                }
            }
            if (hit.transform.gameObject.tag == "Highlightable" || hit.transform.gameObject.tag == "Door" || hit.transform.gameObject.tag == "Key" || hit.transform.gameObject.tag == "CorrectKey" || hit.transform.gameObject.tag == "Crystal") {
                 // checks to see if user is looking at an interactable object then tells the program to highlight the relevant object
                if (Vector3.Distance(cam.transform.position, hit.transform.position) < 3f)
                {
                    highlight = true;
                }
                
            }
            else
            {
                highlight = false;
            }


            if (highlight == true)
            {
      
                Highlight(hit.transform.gameObject);
            }
            else if (unHighlight == true)
            {
                Unhighlight(tempObj);
            }
        
        }


        if (Input.GetMouseButtonDown(0))
        {
            Ray ray = cam.ScreenPointToRay(Input.mousePosition);


            if (Physics.Raycast(ray, out hit))
            {
                hitObj = hit.transform.gameObject;
                if (hitObj.transform != null)
                {
                    
                        if (highlight == true)
                        {
                            if (hitObj.transform.gameObject.tag == "CorrectKey" && hitObj.GetComponent<Renderer>().material.color == highL)
                            {
                                key = true;                          
                                Destroy(hitObj);    // uses destroy object to simulate picking up keys and crystal when clicked on
                            }
                            else if (hitObj.gameObject.tag == "Key" && hitObj.GetComponent<Renderer>().material.color == highL)
                            {
                                Destroy(hitObj);
                            }
                            else if (hitObj.gameObject.tag == "Crystal" && hitObj.GetComponent<Renderer>().material.color == highL)
                            {
                                Destroy(hitObj);

                                
                                win = true;
                                wI.text = "YOU WIN! PRESS SPACE TO CLOSE THE GAME";// outputs the win text and gives player next instructions
                                
                            }

                            else if (hitObj.name == "Door1" && hitObj.GetComponent<Renderer>().material.color == highL)
                            {
                            if (key == true)
                            {
                                traget = hitObj.transform.position + new Vector3(0, 1, 0);

                                move = true; // door1 has to be seperate due to the requirement of a key
                            }
                            }
                            else if (hitObj.tag == "Door"  && hitObj.GetComponent<Renderer>().material.color == highL)
                            {
                                traget = hitObj.transform.position + new Vector3(0, 1, 0);

                                move = true;
                            }

                        }
                
                }
            }
        }
        if (move == true)
        {
            
            oBject = hitObj;
            moveDoor(oBject); // moves the doors
            
        }
        if (win == true && Input.GetButtonDown("Jump"))
        { // closes the application when the win statement is complete and player presses space bar
            Application.Quit();
            //SceneManager.LoadScene("GameScene"); couldnt get this to reload the scene
        }
        
    }
}
